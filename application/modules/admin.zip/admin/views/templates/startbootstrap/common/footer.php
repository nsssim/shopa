<footer class="main-footer">
       
        <strong>Copyright &copy; 2015-2016 <a href="http://www.trendit.com.tr">TrendIT</a>.</strong> All rights reserved.
      </footer>

      <!-- Control Sidebar -->
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>

    </div><!-- ./wrapper -->