
	<?php
	// load the url helper for base_url 
	$this->load->helper('url');
	$template_path= base_url()."assets/templates/adminlte/";
	 ?>  

      

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
             Miscellaneous...
            <small>AmerikaShop</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Miscellaneous... </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
        
	       		<!--other links -->
			       	<div class="col-md-12" style="/*background-color: orange*/" >
			       	 	<div class="col-md-4" style="border: solid 1px #777;  line-height: 20px; width: 250px; text-align: center;">
			       	 		
				       		<a href="<?php echo base_url().'admin/reset_redis_via_ssh' ?>" target="_blank" style="color: black;" >
				       			<img height="100px" src="<?php echo base_url().'assets/system/icon-redis.png';  ?>" /><br>
				       			Restart Redis Server
				       		</a>
			       	 	</div>
			       	 	
			       	 	<div class="col-md-1"> &nbsp; </div>
			       	 	
			       	 	<div class="col-md-4" style="border: solid 1px #777;  line-height: 20px; width: 250px; text-align: center;">
				       		<a  href="https://shopamerika.com:10000" target="_blank" style="color: black;" >
				       			<img height="100px" src="<?php echo base_url().'assets/system/webmin-icon.png';  ?> " /><br>
				       			Access Webmin
				       		</a>
			       	 	</div>
			       	 	
			       	 	<div class="col-md-1"> &nbsp; </div>
			       	 	
			       	 	<div class="col-md-4" style="border: solid 1px #777;  line-height: 20px; width: 250px; text-align: center;">
				       		<a  href="<?php echo base_url().'doc/html/classes.html' ?>" target="_blank" style="color: black;" >
				       			<img height="100px" src="<?php echo base_url().'assets/system/code.png';  ?> " /><br>
				       			Doc For developers
				       		</a>
			       	 	</div>
			       	</div>
			       	
			       	
			    <!--other links -->
       
        
        
    
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      

 