<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class categories extends MX_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		//load file
		$this->load->helper("url");
		$jsonFilename = file_get_contents(base_url()."application/modules/categories/controllers/categories.json");
		$json = json_decode($jsonFilename);
		
		//count num of objects in the json file
		$total_cat=0; 
		foreach($json->categories as $foo) $total_cat++;
		
		$A["json"] = $json;
		$A["total_cat"] = $total_cat;
		
		$this->load->view('categories_vew',$A);
		
		
	}
	
	// get_subcategories($cat_id)  will return somethinglike this 
	/*	
	Array
	(
    [0] => Array
        (
            [name] => Activewear Jackets
            [id] => 15
        )

    [1] => Array
        (
            [name] => Activewear Pants
            [id] => 16
        )
    ....
    */
    
	public function get_subcategories($cat_id)
	{
		$subcat_id_array = array();
		$subcat_name_array = array();
		$this->load->model("categories_mdl");
		$categories_id = $this->categories_mdl->get_cat_tree($cat_id);
		foreach($categories_id as $row)
		{
			//populate the array with categories id
			if($row->lev5_id) $subcat_id_array[] = $row->lev5_id ;
			elseif($row->lev4_id) $subcat_id_array[] = $row->lev4_id ;
			elseif($row->lev3_id) $subcat_id_array[] = $row->lev3_id ;
			elseif($row->lev2_id) $subcat_id_array[] = $row->lev2_id ;
		}
		
		$lang_id = $this->session->userdata("language_id");
		foreach($subcat_id_array as $key=>$value)
		{
			$category_name = $this->categories_mdl->get_cat_name($value,$lang_id);
			foreach($category_name as $row)
			{
				if($row->name) {$subcat_name_array[] = ["name"=>$row->name ,"id"=> $row->id] ;}
				elseif($row->shortName) {$subcat_name_array[] = ["name"=>$row->shortName ,"id"=> $row->id] ;} 
				elseif($row->localizedId) {$subcat_name_array[] = ["name"=>$row->localizedId ,"id"=> $row->id] ;} 
			}	
		}
		sort($subcat_name_array);
		
		//echo "<pre>";
		//print_r($subcat_name_array) ;
		//echo "</pre>";
		
		//return $subcat_name_array;	
	}
	
	//get the subcategories id
	public function get_sub_cat_id($cat_id)
	{
		$this->load->model("categories_mdl");
		$categories_ids = $this->categories_mdl->get_cat_tree($cat_id);
		$sub_cat_list_id_arr = array();
		foreach($categories_ids as $row)
		{
			// check for duplicate and NULL value
			if(!array_search($row->lev6_id,$sub_cat_list_id_arr )&& $row->lev6_id ) $sub_cat_list_id_arr[] = $row->lev6_id ;
			if(!array_search($row->lev5_id,$sub_cat_list_id_arr )&& $row->lev5_id ) $sub_cat_list_id_arr[] = $row->lev5_id ;
			if(!array_search($row->lev4_id,$sub_cat_list_id_arr )&& $row->lev4_id ) $sub_cat_list_id_arr[] = $row->lev4_id ;
			if(!array_search($row->lev3_id,$sub_cat_list_id_arr )&& $row->lev3_id ) $sub_cat_list_id_arr[] = $row->lev3_id ;
			if(!array_search($row->lev2_id,$sub_cat_list_id_arr )&& $row->lev2_id ) $sub_cat_list_id_arr[] = $row->lev2_id ;
			if(!array_search($row->lev1_id,$sub_cat_list_id_arr )&& $row->lev1_id ) $sub_cat_list_id_arr[] = $row->lev1_id ;
		}
		
		$sub_cat_list = "0";
		foreach($sub_cat_list_id_arr as $key=>$value)
		{
			$sub_cat_list = $sub_cat_list.",".$value;
		}
		
		//return $sub_cat_list;
		//echo "<pre>";
		//print_r($sub_cat_list) ;
		//echo "</pre>";
	
	}
	
	//get the id from the idd 
	private function get_cat_id($idd)
	{
		$this->load->model("categories_mdl");
		return $this->categories_mdl->get_cat_id($idd);
	}
	
	public function get_subcat_details($idd)
	{
		$lang_id = $this->session->userdata("language_id");
	
		$this->load->model("categories_mdl");
		$subcategories_details  =  $this->categories_mdl->get_subcat($idd,$lang_id);
	
		/*echo "<pre>";
			print_r($subcategories_details) ;
		echo "</pre>";*/
		
		$this->load->module("product");
		$cat_id = $this->get_cat_id($idd); 
		
		
		
		//echo $cat_id[0]->id;
		
		$cat_products = $this->product->get_cat_products($cat_id[0]->id);
		
		/*echo "----- <br>";*/
		
		/*echo "<pre>";
			print_r($cat_products) ;
		echo "</pre>";*/
		
		$data = array();
		$data[] = ["subcategories_details"=>$subcategories_details , "cat_products" => $cat_products];
		
		//echo "<pre>";
		//	print_r($data) ;
		//echo "</pre>";
		
		$this->load->view("sdfsdfsd",$data);
		
		
		
	}
	
	public function footer()
	{
		//load file
		$this->load->helper("url");
		$jsonFilename = file_get_contents(base_url()."application/modules/categories/controllers/categories.json");
		$json = json_decode($jsonFilename);

		//count num of objects in the json file
		$total_cat=0;
		foreach($json->categories as $foo) $total_cat++;

		$A["json"] = $json;
		$A["total_cat"] = $total_cat;

		$this->load->view('categories_vew_footer',$A);
	}
	
	//return $subcategories_details;
	
}

/* End of file categories.php */
/* Location: .application/modules/categories/controllers/categories.php */