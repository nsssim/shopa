<!--____________________________________/ meta \____________________________________ -->  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <meta name="description " content=" <?php  echo($meta_description); ?> " >
	<meta name="keywords" content=" <?php  echo($meta_keywords); ?>" >
    <meta name="author" content="TrendIT - Home baked " >
    
<!--____________________________________/ favicon \____________________________________ -->
<link rel='shortcut icon' type='image/ico' href= "<?php echo base_url().'assets/templates/Eshopper/images/home/favicon.ico';?>"  >

<!--____________________________________/ title \____________________________________ -->
    <title>  <?php echo($page_title);  ?>  </title>
      
<!--____________________________________/ css \____________________________________-->

	<link href="<?php echo base_url().'assets/'.$template_info['path'].'/css/bootstrap.min.css';?>" rel="stylesheet">	
    <link href="<?php echo base_url().'assets/templates/Eshopper/css/font-awesome.min.css';?>" 		rel="stylesheet">
    <link href="<?php echo base_url().'assets/templates/Eshopper/css/prettyPhoto.css';?>" 		    rel="stylesheet">
    <link href="<?php echo base_url().'assets/templates/Eshopper/css/price-range.css';?>" 			rel="stylesheet">
    <link href="<?php echo base_url().'assets/templates/Eshopper/css/animate.css';?>" 				rel="stylesheet">
	<link href="<?php echo base_url().'assets/templates/Eshopper/css/main.css';?>" 					rel="stylesheet">
	<link href="<?php echo base_url().'assets/templates/Eshopper/css/responsive.css';?>" rel="stylesheet">

<!--____________________________________/ responsive \____________________________________-->

    <!--[if lt IE 9]>
    <script src= "<?php echo base_url().'assets/templates/Eshopper/css/js/html5shiv.js';?>"   ></script>
    <script src= "<?php echo base_url().'assets/templates/Eshopper/css/js/respond.min.js';?>" ></script>
    <![endif]-->   
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url().'assets/templates/Eshopper/images/ico/apple-touch-icon-144-precomposed.png';?>"  >
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url().'assets/templates/Eshopper/images/ico/apple-touch-icon-114-precomposed.png';?>"  >
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url().'assets/templates/Eshopper/images/ico/apple-touch-icon-72-precomposed.png';?>" 	  >
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url().'assets/templates/Eshopper/images/home/gallery3.jpg';?>" >
